
type __ = Obj.t

(** val negb : bool -> bool **)

let negb = function
| true -> false
| false -> true



(** val eqb : bool -> bool -> bool **)

let eqb b1 b2 =
  if b1 then b2 else if b2 then false else true

module Nat =
 struct
  (** val leb : int -> int -> bool **)

  let rec leb = (fun n m -> n <= m)

  (** val ltb : int -> int -> bool **)

  let ltb = (fun n m -> n < m)
 end

type extractableRuptureCert = { ec_left_id : int; ec_right_id : int;
                                ec_obs_hash : int; ec_pred_left : bool;
                                ec_pred_right : bool; ec_fatigue : int }

type extractable_cert_semantically_valid = __

(** val extracted_cert_valid : extractableRuptureCert -> bool **)

let extracted_cert_valid cert =
  if negb (eqb cert.ec_pred_left cert.ec_pred_right)
  then Nat.ltb 0 cert.ec_fatigue
  else false



type extractableEngineeringAction = {
  ea_ticket_kind : int;
  ea_monitor_status : int;
  ea_repair_recommendation : int;
  ea_debt_kind : int;
  ea_restriction_cost : int;
  ea_refinement_cost : int }

let ticket_none = 0
let ticket_admissibility_failure = 1
let repair_no_action = 0
let repair_refine_observation = 2
let repair_choose_by_cost = 3
let repair_carry_explicit_debt = 4
let debt_boundary = 3
let debt_threshold = 4

let recommended_repair_for_debt_kind debt_kind =
  if Nat.leb debt_threshold debt_kind && Nat.leb debt_kind debt_threshold
  then repair_carry_explicit_debt
  else if Nat.leb debt_boundary debt_kind && Nat.leb debt_kind debt_boundary
       then repair_refine_observation
       else repair_choose_by_cost

let engineering_action_from_status status restriction_cost refinement_cost debt_kind =
  if Nat.leb status 0 && Nat.leb 0 status then
    { ea_ticket_kind = ticket_none; ea_monitor_status = 0;
      ea_repair_recommendation = repair_no_action; ea_debt_kind = debt_kind;
      ea_restriction_cost = restriction_cost; ea_refinement_cost = refinement_cost }
  else
    { ea_ticket_kind = ticket_admissibility_failure; ea_monitor_status = status;
      ea_repair_recommendation = recommended_repair_for_debt_kind debt_kind;
      ea_debt_kind = debt_kind; ea_restriction_cost = restriction_cost;
      ea_refinement_cost = refinement_cost }

let engineering_action_from_certificate cert restriction_cost refinement_cost debt_kind =
  if extracted_cert_valid cert
  then engineering_action_from_status 2 restriction_cost refinement_cost debt_kind
  else engineering_action_from_status 0 restriction_cost refinement_cost debt_kind

(** val build_extractable_cert :
    bool -> bool -> int -> extractableRuptureCert **)

let build_extractable_cert pl pr fat =
  { ec_left_id = 0; ec_right_id = (succ 0); ec_obs_hash = 0; ec_pred_left =
    pl; ec_pred_right = pr; ec_fatigue = fat }
