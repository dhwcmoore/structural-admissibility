
type __ = Obj.t

val negb : bool -> bool



val eqb : bool -> bool -> bool

module Nat :
 sig
  val leb : int -> int -> bool

  val ltb : int -> int -> bool
 end

type extractableRuptureCert = { ec_left_id : int; ec_right_id : int;
                                ec_obs_hash : int; ec_pred_left : bool;
                                ec_pred_right : bool; ec_fatigue : int }

type extractable_cert_semantically_valid = __

val extracted_cert_valid : extractableRuptureCert -> bool



type extractableEngineeringAction = {
  ea_ticket_kind : int;
  ea_monitor_status : int;
  ea_repair_recommendation : int;
  ea_debt_kind : int;
  ea_restriction_cost : int;
  ea_refinement_cost : int }

val engineering_action_from_certificate :
  extractableRuptureCert -> int -> int -> int -> extractableEngineeringAction

val build_extractable_cert : bool -> bool -> int -> extractableRuptureCert
